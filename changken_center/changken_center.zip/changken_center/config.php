﻿<?php
mysql_pconnect(
"", //MySQL資料庫主機地址
"", //MySQL資料庫使用者名稱
""  //MySQL資料庫使用者密碼
);
mysql_query("SET NAMES UTF-8");
mysql_select_db(
"" //MySQL資料庫名稱
);
?>